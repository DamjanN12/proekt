package mk.finki.ukim.mk.lab.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(authorizeRequests -> authorizeRequests
                        .requestMatchers("/login", "/logout").permitAll()  // Дозволи пристап до login и logout
                        .requestMatchers("/add-event", "/bookingConfirmation", "/listEvents").authenticated()  // Потребен е логин за овие страници
                        .requestMatchers("/events/add", "/events/edit/{eventId}", "/events/delete/{eventId}").hasRole("ADMIN")  // Само администратори можат да додадат, уредуваат или бришат
                )
                .formLogin(form -> form
                        .loginPage("/login")  // Страницата за login
                        .defaultSuccessUrl("/events", true)  // Доколку е успешен login, ќе се пренасочи на /events
                        .permitAll()  // Дозволи јавен пристап до login страната
                )
                .logout(logout -> logout.permitAll());  // Дозволи излогирање

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }


    public UserDetailsService userDetailsService(PasswordEncoder passwordEncoder) {
        UserDetails admin = User.builder()
                .username("admin")
                .password(passwordEncoder.encode("admin123"))
                .roles("ADMIN")
                .build();

        UserDetails user = User.builder()
                .username("user")
                .password(passwordEncoder.encode("user123"))
                .roles("USER")
                .build();

        return new InMemoryUserDetailsManager(admin, user);
    }
}

