package mk.finki.ukim.mk.lab.repository;

public interface JpaRepository<T, T1> {
}
