package com.example.lab1emt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1EmtApplicationTests {

    @Test
    void contextLoads() {
    }

}
