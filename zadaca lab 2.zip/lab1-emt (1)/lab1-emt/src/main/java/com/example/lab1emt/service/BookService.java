package com.example.lab1emt.service;

import com.example.lab1emt.model.Author;
import com.example.lab1emt.model.BookEntity;
import com.example.lab1emt.model.dto.BookDto;
import com.example.lab1emt.repository.AuthorRepository;
import com.example.lab1emt.repository.BookRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public BookService(BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }

    public List<BookEntity> findAll() {
        return bookRepository.findAll();
    }

    public BookEntity addBook(BookDto bookDto) throws Exception {
        Author author = authorRepository.findById(bookDto.authorId).orElseThrow(Exception::new);
        BookEntity bookEntity = new BookEntity(bookDto.name, bookDto.category, author, bookDto.availableCopies);
        bookRepository.save(bookEntity);
        return bookEntity;
    }

    public BookEntity updateBook(Long bookId, BookDto bookDto) throws Exception {
        BookEntity bookEntity = bookRepository.findById(bookId).orElseThrow(Exception::new);
        Author author = authorRepository.findById(bookDto.authorId).orElseThrow(Exception::new);
        bookEntity.setName(bookDto.name);
        bookEntity.setCategory(bookDto.category);
        bookEntity.setAuthor(author);
        bookEntity.setAvailableCopies(bookDto.availableCopies);
        bookRepository.save(bookEntity);
        return bookEntity;
    }

    public void updateAvailableCopies(Long bookId) throws Exception {
        BookEntity bookEntity = bookRepository.findById(bookId).orElseThrow(Exception::new);
        bookEntity.setAvailableCopies(bookEntity.getAvailableCopies() - 1);
        bookRepository.save(bookEntity);
    }

    public void delete(Long bookId) {
        bookRepository.deleteById(bookId);
    }
}
