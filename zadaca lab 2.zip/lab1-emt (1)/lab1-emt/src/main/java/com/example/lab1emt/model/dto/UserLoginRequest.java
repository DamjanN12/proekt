package com.example.lab1emt.model.dto;

public class UserLoginRequest {
    public String username;
    public String password;
}
