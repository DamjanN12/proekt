package com.example.lab1emt.service;

import com.example.lab1emt.model.BookEntity;
import com.example.lab1emt.model.UserEntity;
import com.example.lab1emt.model.Wishlist;
import com.example.lab1emt.repository.BookRepository;
import com.example.lab1emt.repository.UserRepository;
import com.example.lab1emt.repository.WishlistRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WishlistService {
    private final WishlistRepository wishlistRepository;
    private final BookRepository bookRepository;

    public WishlistService(WishlistRepository wishlistRepository, BookRepository bookRepository) {
        this.wishlistRepository = wishlistRepository;
        this.bookRepository = bookRepository;
    }

    public Wishlist getUserWishlist(UserEntity userEntity) {
        return userEntity.getWishlist();
    }

    public void addBookToWishlist(UserEntity userEntity, Long bookId) throws Exception {
        BookEntity bookEntity = bookRepository.findById(bookId).orElseThrow(Exception::new);
        Wishlist wishlist = userEntity.getWishlist();

        if(bookEntity.getAvailableCopies() > 0) {
            wishlist.getBookEntities().add(bookEntity);
            wishlistRepository.save(wishlist);
        } else {
            throw new Exception("You cannot add this book to wishlist");
        }
    }

    public void rentAllBooksFromWishlist(UserEntity userEntity) {
        Wishlist wishlist = userEntity.getWishlist();
        List<BookEntity> books = wishlist.getBookEntities();
        for(BookEntity book : books) {
            book.setAvailableCopies(book.getAvailableCopies() - 1);
            bookRepository.save(book);
        }
    }
}
