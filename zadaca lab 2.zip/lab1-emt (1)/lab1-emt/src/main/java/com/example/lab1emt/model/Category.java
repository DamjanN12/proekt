package com.example.lab1emt.model;

public enum Category {
    NOVEL,
    THRILLER,
    HISTORY,
    FANTASY,
    BIOGRAPHY,
    CLASSICS,
    DRAMA
}
