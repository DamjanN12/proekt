package com.example.lab1emt.model;

public enum UserRole {
    USER,
    LIBRARIAN
}
