package com.example.lab1emt.controller;

import com.example.lab1emt.model.dto.UserLoginRequest;
import com.example.lab1emt.model.dto.UserRegisterRequest;
import com.example.lab1emt.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/user/register")
    public ResponseEntity<Void> registerUser(@RequestBody UserRegisterRequest userRegisterRequest) {
        System.out.println("called register");
        userService.registerUser(userRegisterRequest.username, userRegisterRequest.password);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/user/login")
    public ResponseEntity<Void> login(@RequestBody UserLoginRequest userLoginRequest) {
        System.out.println(userLoginRequest.username);
        System.out.println("CALLED controller");
//        userService.loadUserByUsername(userLoginRequest.username);
        return ResponseEntity.noContent().build();
    }
}
