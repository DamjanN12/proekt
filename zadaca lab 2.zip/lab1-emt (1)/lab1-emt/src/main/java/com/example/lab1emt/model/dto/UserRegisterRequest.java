package com.example.lab1emt.model.dto;

public class UserRegisterRequest {
    public String username;
    public String password;
}
