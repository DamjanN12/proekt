package com.example.lab1emt.data;

import com.example.lab1emt.model.Author;
import com.example.lab1emt.model.Country;
import com.example.lab1emt.repository.AuthorRepository;
import com.example.lab1emt.repository.CountryRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

@Component
public class DataInitializr {

    private final CountryRepository countryRepository;
    private final AuthorRepository authorRepository;

    public DataInitializr(CountryRepository countryRepository, AuthorRepository authorRepository) {
        this.countryRepository = countryRepository;
        this.authorRepository = authorRepository;
    }

    @PostConstruct
    public void initializeData() {
        Country country = new Country("Macedonia", "Europe");
        countryRepository.save(country);

        Author author = new Author("Mladen", "Jovanovski", country);
        authorRepository.save(author);
    }
}
