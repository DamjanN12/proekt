package com.example.lab1emt.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table
public class Wishlist {

    @Id
    @GeneratedValue
    private Long id;

    @ManyToMany
    private List<BookEntity> bookEntities = new ArrayList<>();

    public Wishlist() {
    }

    public Wishlist(Long id, List<BookEntity> bookEntities) {
        this.id = id;
        this.bookEntities = bookEntities;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<BookEntity> getBookEntities() {
        return bookEntities;
    }

    public void setBookEntities(List<BookEntity> bookEntities) {
        this.bookEntities = bookEntities;
    }
}
