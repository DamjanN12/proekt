package com.example.lab1emt.controller;

import com.example.lab1emt.model.BookEntity;
import com.example.lab1emt.model.UserEntity;
import com.example.lab1emt.model.dto.BookDto;
import com.example.lab1emt.service.BookService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class BookRestController {

    private final BookService bookService;

    public BookRestController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/book")
    public ResponseEntity<List<BookEntity>> findAll() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        System.out.println(currentPrincipalName);
        return ResponseEntity.ok(bookService.findAll());
    }

    @PostMapping("/book")
    public ResponseEntity<BookEntity> addBook(@RequestBody BookDto bookDto) throws Exception {
        return ResponseEntity.ok(bookService.addBook(bookDto));
    }

    @PutMapping("/book/{id}")
    public ResponseEntity<BookEntity> updateBook(@PathVariable Long id, @RequestBody BookDto bookDto) throws Exception {
        return ResponseEntity.ok(bookService.updateBook(id, bookDto));
    }

    @PutMapping("/book/availableCopies/{id}")
    public ResponseEntity<Void> updateAvailableCopies(@PathVariable Long id) throws Exception {
        bookService.updateAvailableCopies(id);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/book/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        bookService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
