package com.example.demo.controller;

import com.example.demo.model.Book;
import com.example.demo.model.dto.AuthorDto;
import com.example.demo.service.BookService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@SecurityRequirement(name="basicAuth")
public class BookRestController {
    private final BookService bookService;

    public BookRestController(BookService bookService) {
        this.bookService = bookService;
    }
    @GetMapping("/book")
    public ResponseEntity<List<Book>> findAll(){
        return ResponseEntity.ok(bookService.findAll());
    }
    @PreAuthorize("hasRole('LIBRARIAN')")
    @PostMapping("/book")
    public ResponseEntity<Book> addBook(@RequestBody AuthorDto authorDto) throws Exception {
        return ResponseEntity.ok(bookService.addBook(authorDto));
    }
    @DeleteMapping("/book/{id}")
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id){
        bookService.deleteBook(id);
        return ResponseEntity.noContent().build();
    }
    @PutMapping("/book/{id}")
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<Book> updateBook(@PathVariable Long id,@RequestBody AuthorDto authorDto) throws Exception{
        return ResponseEntity.ok(bookService.updateBook(id,authorDto));
    }
    @PreAuthorize("hasRole('LIBRARIAN')")
    @PutMapping("/book/rentbook/{id}")
    public ResponseEntity<Void> rentBook(@PathVariable Long id) throws Exception{
        bookService.rentBook(id);
        return ResponseEntity.noContent().build();
    }
}
