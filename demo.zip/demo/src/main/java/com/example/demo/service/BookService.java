package com.example.demo.service;

import com.example.demo.model.Author;
import com.example.demo.model.Book;
import com.example.demo.model.dto.AuthorDto;
import com.example.demo.repository.AuthorRepository;
import com.example.demo.repository.BookRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {
    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public BookService(BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }
    public List<Book> findAll(){
        return bookRepository.findAll();
    }
    public Book addBook(AuthorDto authorDto) throws Exception{
        Author author = authorRepository.findById(authorDto.authorId).orElseThrow(Exception::new);
        Book book = new Book(authorDto.name, authorDto.category, author,authorDto.availableCopies);
        bookRepository.save(book);
        return book;
    }
    public void deleteBook(Long bookId){
        bookRepository.deleteById(bookId);
    }
    public Book updateBook(Long bookId, AuthorDto authorDto) throws Exception{
        Book book= bookRepository.findById(bookId).orElseThrow(Exception::new);
        Author author = authorRepository.findById(authorDto.authorId).orElseThrow(Exception::new);
        book.setName(authorDto.name);
        book.setCategory(authorDto.category);
        book.setAuthor(author);
        book.setAvailableCopies(authorDto.availableCopies);
        bookRepository.save(book);
        return book;
    }
    public void rentBook(Long bookId) throws Exception{
        Book book= bookRepository.findById(bookId).orElseThrow(Exception::new);
        book.setAvailableCopies(book.getAvailableCopies()-1);
        bookRepository.save(book);
    }
}
