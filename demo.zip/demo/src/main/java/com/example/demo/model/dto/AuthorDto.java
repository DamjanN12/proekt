package com.example.demo.model.dto;

import com.example.demo.model.Category;

public class AuthorDto {
   public String name;
    public Category category;
    public Long authorId;
    public Integer availableCopies;
}
