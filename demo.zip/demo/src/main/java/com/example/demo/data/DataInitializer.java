package com.example.demo.data;

import com.example.demo.model.Author;
import com.example.demo.model.Country;
import com.example.demo.repository.AuthorRepository;
import com.example.demo.repository.CountryRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer {
    private final CountryRepository countryRepository;
    private final AuthorRepository authorRepository;

    public DataInitializer(CountryRepository countryRepository, AuthorRepository authorRepository) {
        this.countryRepository = countryRepository;
        this.authorRepository = authorRepository;
    }
    @PostConstruct
    public void initializerData(){
        Country country = new Country("Macedonia","Europe");
        countryRepository.save(country);
        Author author = new Author("Damjan","Nikolovski",country);
        authorRepository.save(author);
    }
}
