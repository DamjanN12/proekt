package com.example.lab1emt.controller;

import com.example.lab1emt.model.BookEntity;
import com.example.lab1emt.model.dto.BookDto;
import com.example.lab1emt.service.BookService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@SecurityRequirement(name = "basicAuth")
public class BookRestController {

    private final BookService bookService;

    public BookRestController(BookService bookService) {
        this.bookService = bookService;
    }

    // gi vrakja site knigi
    @GetMapping("/book")
    public ResponseEntity<List<BookEntity>> findAll() {
        return ResponseEntity.ok(bookService.findAll());
    }

    // kreirame kniga
    @PreAuthorize("hasRole('LIBRARIAN')")
    @PostMapping("/book")
    public ResponseEntity<BookEntity> addBook(@RequestBody BookDto bookDto) throws Exception {
        return ResponseEntity.ok(bookService.addBook(bookDto));
    }

    // update na kniga
    @PreAuthorize("hasRole('LIBRARIAN')")
    @PutMapping("/book/{id}")
    public ResponseEntity<BookEntity> updateBook(@PathVariable Long id, @RequestBody BookDto bookDto) throws Exception {
        return ResponseEntity.ok(bookService.updateBook(id, bookDto));
    }

    // namaluvame broj na kopii za 1
    @PreAuthorize("hasRole('LIBRARIAN')")
    @PutMapping("/book/availableCopies/{id}")
    public ResponseEntity<Void> updateAvailableCopies(@PathVariable Long id) throws Exception {
        bookService.updateAvailableCopies(id);
        return ResponseEntity.noContent().build();
    }

    // briseme kniga
    @DeleteMapping("/book/{id}")
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        bookService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
