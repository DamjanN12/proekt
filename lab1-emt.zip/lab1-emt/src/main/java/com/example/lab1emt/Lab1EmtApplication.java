package com.example.lab1emt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab1EmtApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab1EmtApplication.class, args);
    }

}
