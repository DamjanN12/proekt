package com.example.lab1emt.service;

import com.example.lab1emt.model.Author;
import com.example.lab1emt.model.BookEntity;
import com.example.lab1emt.model.dto.BookDto;
import com.example.lab1emt.repository.AuthorRepository;
import com.example.lab1emt.repository.BookRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public BookService(BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }

    public List<BookEntity> findAll() {
        return bookRepository.findAll();
    }

    public BookEntity addBook(BookDto bookDto) throws Exception {
        Author author = authorRepository.findById(bookDto.authorId).orElseThrow(Exception::new);
        BookEntity book = new BookEntity(bookDto.name, bookDto.category, author, bookDto.availableCopies);
        bookRepository.save(book);
        return book;
    }

    public BookEntity updateBook(Long bookId, BookDto bookDto) throws Exception {
        BookEntity book = bookRepository.findById(bookId).orElseThrow(Exception::new);
        Author author = authorRepository.findById(bookDto.authorId).orElseThrow(Exception::new);
        book.setName(bookDto.name);
        book.setCategory(bookDto.category);
        book.setAuthor(author);
        book.setAvailableCopies(bookDto.availableCopies);
        bookRepository.save(book);
        return book;
    }

    public void updateAvailableCopies(Long bookId) throws Exception {
        BookEntity book = bookRepository.findById(bookId).orElseThrow(Exception::new);
        book.setAvailableCopies(book.getAvailableCopies() - 1);
        bookRepository.save(book);
    }

    public void delete(Long bookId) {
        bookRepository.deleteById(bookId);
    }
}
