package com.example.lab1emt.model.dto;

import com.example.lab1emt.model.Category;

public class BookDto {
    public String name;
    public Category category;
    public Long authorId;
    public int availableCopies;
}
