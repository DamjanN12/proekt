package mk.ukim.finki.wp.kol2024g1.model;

public enum RoomType {
    DOUBLE,
    SINGLE
}
